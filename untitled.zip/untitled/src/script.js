function showLove(){
  document.getElementById("msg").style.display = "block";
}

for(let i = 0; i < 100; i++){
  let star = document.createElement("div");
  star.className = "star";
  star.style.left = Math.random() * 100 + "vw";
  star.style.top = Math.random() * 100 + "vh";
  star.style.animationDelay = Math.random() * 2 + "s";
  document.body.appendChild(star);
}